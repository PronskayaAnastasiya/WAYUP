/* 
    Задание 2:

    Необходимо создать объект в котором вы опишите самого себя в формате : "свойство: значение"

    Список свойств:

    - Имя(string)
    - Фамилия(string)
    - Возраст(number)
    - Есть ли домашние животные(boolean)
*/

let Human ={
    firstname: "Nastya",
    lastname: "Pronskaya",
    age: 18,
    pet: true
}

console.log(Human);