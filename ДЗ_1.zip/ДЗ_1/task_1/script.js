/* 
    Задание 1:

    Вам необходимо поделиться информацией о вашем родном городе. Все данные необходимо записать в отдельную переменную.
    Информация о городе: 
    - Название города (строка)
    - В какой стране находится этот город (строка)
    - Численность населения (число)
    - Есть ли футбольный стадион (boolean [ true(да) / false(нет) ])
*/

let city="Grodno";
let country="Belarus";
let population=370000;
let stadium=true;
console.log("City: "+city+"\nCountry: "+country+'\nPopulation: '+population+"\nStadium: "+stadium);